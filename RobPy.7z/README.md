# Projet Python : RobPy et ses simulations...

## Description du projet RobPy

"Datayana Bot Corp." présente le projet RobPy.

Ce projet vise à satisfaire les attentes du client, qui souhaite tester de nouvelle application sur son robot. Cependant, le client ne souhaite surtout ni abîmer, ni oser risquer un quelconque dommage sur son tout nouveau et precieux prototype. C'est pourquoi il nous confie la tâche de définir un environnement de simulation virtuel afin de tester les capacités de la réplique virtuels du robot dans un univers contrôlé.

Les attentes du client sont :
- Le robot doit pouvoir faire un carré
- Le robot doit pouvoir s'approcher d'un mur le plus vite possible sans le toucher
- Le robot doit pouvoir suivre une balise

En fonction de l'avancement des tests et de leurs validités, carte blanche nous est donné quant à l'élaboration d'autre caractéristiques du soft. (A définir)

