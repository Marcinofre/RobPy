# Compte Rendu de la séance

- Troisième entrevue avec le client :
	- Bilan :
		- Négatif :
			- Perte de temps sur des fonctions qui devait (si elle devait venir un jour) implémenté beaucoup plus tard dans le projetv (mauvais objectif de sprint...)
			- Création à la main de fonction déjà existante dans des modules
				- Fonction de parsing notamment. (voir cours td3)
			
			- "Quand le client souhaite un supermarché, vous avez décidé de créer l'autoroute qui y amène..."
			- "Une autoroute en terre battue qui plus est !"
				- Bref, c'est pas ce qui est demandé.
			- Code non factoriser (github en vrac)
			- Mauvaise coordination (disproportion de commit entre chacun)
			- On presente sur la branch main, pas ce qui sur dev.
			- La semaine est perdu.
		
		- Positif :
			- On s'est bien amusé 
			- "Vous avez fait des tests unitaires"



	- Pour rattraper le retard, ce qui doit-être fait pour mercredi prochain :
		- avoir une interface graphique fonctionnnelle
		- refactoriser le code (github)
		- avoir une physique basique 
		- Ah et maintenant, dans le trello, l'heure totale doit-être donné.
		- vous avez une semaine, bon courage !

