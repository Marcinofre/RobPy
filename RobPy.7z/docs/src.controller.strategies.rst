src.controller.strategies package
=================================

Submodules
----------

src.controller.strategies.metastrats module
-------------------------------------------

.. automodule:: src.controller.strategies.metastrats
   :members:
   :undoc-members:
   :show-inheritance:

src.controller.strategies.unitstrats module
-------------------------------------------

.. automodule:: src.controller.strategies.unitstrats
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: src.controller.strategies
   :members:
   :undoc-members:
   :show-inheritance:
