#class Gemme:

#   def __init__(self, x: float, y: float) -> None:
    
#       self._position_x = x
#		self._position_y = y